# La Cava — Registro HACCP (versione Firebase)

Migrato da Supabase a **Firebase (Firestore + Authentication, piano Spark
gratuito)** per eliminare la pausa automatica per inattività. Stessa app,
stesse funzioni, backend diverso — vedi `firebase/SCHEMA.md` per il
dettaglio di cosa è cambiato nei dati.

Nessun passaggio di build: sono file statici, pubblicabili così come sono.

---

## 1. Creare il progetto Firebase

1. Vai su [console.firebase.google.com](https://console.firebase.google.com) → **Aggiungi progetto** → dagli un nome (es. "la-cava-haccp") → puoi disattivare Google Analytics, non serve.
2. Nel progetto, clicca l'icona **Web** (`</>`) per registrare una nuova app web. Dagli un nome, non serve l'hosting Firebase.
3. Copia l'oggetto `firebaseConfig` mostrato a schermo (contiene apiKey, authDomain, projectId, ecc.).

## 2. Configurare l'app

Apri `src/lib/config.js` e sostituisci i placeholder con i valori copiati al punto precedente:

```js
export const FIREBASE_CONFIG = {
  apiKey: "...",
  authDomain: "la-cava-haccp.firebaseapp.com",
  projectId: "la-cava-haccp",
  storageBucket: "la-cava-haccp.appspot.com",
  messagingSenderId: "...",
  appId: "...",
};
```

## 3. Attivare Authentication e Firestore

1. Nella console Firebase, **Build → Authentication → Get started** → scheda "Sign-in method" → attiva **Email/Password**.
2. **Build → Firestore Database → Create database** → scegli **Modalità produzione** (non "modalità test") → seleziona una regione europea.
3. Vai su **Firestore Database → Regole**, cancella il contenuto e incolla quello di `firebase/firestore.rules` (in questo progetto) → **Pubblica**.

## 4. Creare il tuo utente

1. **Authentication → Users → Add user** → inserisci la tua email e una password.
2. Copia lo **User UID** generato.
3. **Firestore Database → Dati → Avvia raccolta** → ID raccolta: `profili` → ID documento: **incolla lo User UID copiato sopra** → aggiungi i campi:
   - `nome` (string) → il tuo nome
   - `ruolo` (string) → `responsabile`
   - `attivo` (boolean) → `true`

## 5. Configurare le apparecchiature, pulizie e procedure

Sempre da **Firestore Database → Dati**, crea le raccolte e i documenti seguenti (un documento per riga; puoi aggiungere ogni campo manualmente dall'interfaccia, senza scrivere query):

**Raccolta `apparecchiature`** — 6 documenti, campi `nome` (string), `tipo` (string: `frigorifero` o `freezer`), `limite_minimo` (number, solo frigoriferi), `limite_massimo` (number), `ordine` (number), `attivo` (boolean: `true`):

| nome | tipo | limite_minimo | limite_massimo | ordine |
|---|---|---|---|---|
| Frigo 3 ante | frigorifero | 0 | 4 | 1 |
| Frigo a colonna | frigorifero | 0 | 4 | 2 |
| Frigo domestico (pasta) | frigorifero | 0 | 4 | 3 |
| Frigo acqua (saletta) | frigorifero | 0 | 4 | 4 |
| Freezer ghiaccio | freezer | — | -18 | 5 |
| Freezer surgelati | freezer | — | -18 | 6 |

**Raccolta `piano_pulizie`** — campi `nome` (string), `frequenza` (string: `giornaliera`/`settimanale`/`mensile`), `ordine` (number), `attivo` (boolean: `true`):

| nome | frequenza | ordine |
|---|---|---|
| Piani di lavoro e superfici | giornaliera | 1 |
| Affettatrice | giornaliera | 2 |
| Roner e vasca | giornaliera | 3 |
| Pavimenti | giornaliera | 4 |
| Interno frigoriferi | settimanale | 5 |
| Abbattitore | settimanale | 6 |
| Magazzino / scaffali | mensile | 7 |

**Raccolta `procedure_approvate`** (facoltativa — senza questa, il Registro funziona comunque ma senza calcolo automatico OK/fuori limite) — campi `tipo` (string), `nome` (string), `stato` (string: `approvata`), `parametri` (mappa):

- documento 1: `tipo: abbattimento`, `nome: Abbattimento standard`, `parametri: { temperatura_max_c: 10, tempo_max_min: 90 }`
- documento 2: `tipo: rigenerazione`, `nome: Rigenerazione standard`, `parametri: { temperatura_min_c: 65 }`

## 6. Provare in locale

Serve solo un server statico qualsiasi (nessun build). Da questa cartella:

```bash
npx serve .
```

Apri l'indirizzo mostrato, poi naviga su `public/index.html`. Accedi con l'email e la password create al punto 4.

**La prima volta che apri ogni schermata**, se una query richiede un indice composito non ancora esistente, Firestore mostra un errore in console con un link diretto per crearlo in un clic — è normale, non un bug (vedi `firebase/SCHEMA.md`).

## 7. Pubblicare su Cloudflare Pages (gratuito)

1. Carica questa cartella su un repository GitHub.
2. Su Cloudflare → **Workers & Pages → Create → Pages → Connect to Git** → seleziona il repository.
3. Come "Build output directory" indica `public` (oppure la root, se preferisci spostare `index.html` lì — vedi nota sotto).
4. Deploy. Ottieni un indirizzo gratuito `nome-progetto.pages.dev`, da aggiungere alla schermata Home del telefono.

**Nota sui percorsi:** `public/index.html` referenzia `src/` con percorsi relativi (`../src/...`), quindi va servito insieme al resto della cartella del progetto, non spostato da solo.

**Ping automatico non più necessario**: Firebase Spark non mette mai in pausa il progetto per inattività, quindi il workflow GitHub Actions della versione Supabase è stato rimosso — un componente in meno da mantenere.

## 8. Aggiungerla alla schermata Home del telefono

Apri l'indirizzo `pages.dev` dal telefono: su iPhone **Condividi → Aggiungi a Home**, su Android **menu del browser → Aggiungi a schermata Home**.

---

## Cosa cambia rispetto alla versione Supabase

- **Nessuna pausa per inattività** — il motivo della migrazione. Il progetto Firebase resta sempre attivo.
- **Offline più semplice, non più complesso**: Firestore mette in coda da solo le scritture fatte senza rete e le invia quando torna la connessione. Il livello `db-local.js`/Dexie scritto a mano per Supabase non serve più — è stato rimosso, non solo sostituito.
- **Prodotti e Schede HACCP ora funzionano anche offline** (con la versione Supabase richiedevano connessione): con Firestore, ogni scrittura si mette in coda automaticamente, anche per queste due sezioni.
- **Storico legge da Firestore invece che da una cache locale per-dispositivo**: significa che, a differenza della versione Supabase, la cronologia è la stessa se in futuro accedi da un altro dispositivo — un limite che avevamo segnalato prima ed è stato risolto dal cambio di backend.
- **Allergeni incorporati nel documento prodotto** invece di una tabella di giunzione separata — più naturale in un database a documenti come Firestore.

## Cosa fa questa versione

Oggi (cruscotto giornaliero), Controlli (Temperature + Registro CBT/abbattimento/rigenerazione), Pulizie (giornaliere/settimanali/mensili), Anomalie (pulsante "!" sempre visibile), Prodotti (anagrafica + 14 allergeni), Ricevimento merci, Schede HACCP (versionamento, stati bozza/da revisionare/approvata), Storico con stampa/esportazione PDF. Login con sessione persistente. Offline su tutte le sezioni.

## Limiti noti

- **OCR etichetta e barcode non ancora implementati**: la sezione Prodotti prevede solo l'inserimento manuale per ora.
- **Ricerca prodotto per nome esatto**: in Ricevimento merci, il collegamento automatico a un prodotto già esistente cerca una corrispondenza esatta del nome, non parziale/case-insensitive.
- **Non testato contro un progetto Firebase reale**: il codice è stato verificato per sintassi e coerenza degli import, ma la prima prova vera sarà la tua, seguendo i passi 1–6 sopra.

## Cosa manca ancora

OCR etichetta, lettura barcode, HACCP Input con AI, assistente "Chiedi all'HACCP", generazione automatica del manuale HACCP, knowledge base normativa — tutte rimandate a MVP2/V3 come da architettura approvata.
