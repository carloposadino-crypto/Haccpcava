import { getSession, getProfilo, onAuthStateChange, signOut } from './lib/auth.js';
import { onSyncStatusChange } from './lib/sync-status.js';
import { renderLogin } from './screens/login/login.js';
import { renderOggi } from './screens/oggi/oggi.js';
import { renderControlli } from './screens/controlli/index.js';
import { renderPulizie } from './screens/pulizie/pulizie.js';
import { renderAnomalie } from './screens/anomalie/anomalie.js';
import { renderAltro } from './screens/altro/altro.js';
import { renderProdotti } from './screens/prodotti/prodotti.js';
import { renderRicevimento } from './screens/ricevimento/ricevimento.js';
import { renderSchedeHaccp } from './screens/schede-haccp/schede-haccp.js';
import { renderStorico } from './screens/storico/storico.js';
import { apriModaleAnomalia } from './components/anomalia-modal.js';

const root = document.getElementById('root');

const TAB_PRINCIPALI = [
  ['oggi', 'Oggi', 'home'],
  ['controlli', 'Controlli', 'thermo'],
  ['pulizie', 'Pulizie', 'spray'],
  ['anomalie', 'Anomalie', 'alert'],
  ['altro', 'Altro', 'more'],
];
const TITOLI = {
  oggi: 'Registro di oggi', controlli: 'Controlli', pulizie: 'Pulizie e sanificazione',
  anomalie: 'Anomalie', altro: 'Altro', prodotti: 'Prodotti', ricevimento: 'Ricevimento merci',
  'schede-haccp': 'Schede HACCP', storico: 'Storico',
};
const SOTTO_SCHERMATE = ['prodotti', 'ricevimento', 'schede-haccp', 'storico'];

function icona(nome) {
  const path = {
    home: '<path d="M3 11.5 12 4l9 7.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.5 10v9a1 1 0 0 0 1 1H9a1 1 0 0 0 1-1v-4h4v4a1 1 0 0 0 1 1h2.5a1 1 0 0 0 1-1v-9" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>',
    thermo: '<path d="M12 3a2 2 0 0 0-2 2v9.17a3.5 3.5 0 1 0 4 0V5a2 2 0 0 0-2-2Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="12" cy="17" r="1.4" fill="currentColor"/>',
    spray: '<path d="M9 3h3v3H9z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M10.5 6v2M7 10h7a2 2 0 0 1 2 2v7a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1v-9Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
    alert: '<path d="M12 4 3 20h18L12 4Z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><path d="M12 10v4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="17" r="1" fill="currentColor"/>',
    more: '<circle cx="5" cy="12" r="1.6" fill="currentColor"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><circle cx="19" cy="12" r="1.6" fill="currentColor"/>',
  };
  return `<svg viewBox="0 0 24 24">${path[nome]}</svg>`;
}

let statoApp = { tab: 'oggi', profilo: null };

function costruisciShell() {
  root.innerHTML = `
    <header class="topbar">
      <p class="brand">TENUTA AGRICOLA LA CAVA</p>
      <div style="display:flex; align-items:center; justify-content:space-between;">
        <h1 id="titolo-schermata">${TITOLI[statoApp.tab]}</h1>
        ${SOTTO_SCHERMATE.includes(statoApp.tab) ? `<button class="btn-ghost" id="indietro-btn" style="padding:6px 12px;font-size:12px;border-radius:8px;">‹ Indietro</button>` : ''}
      </div>
      <p class="sync-status" id="sync-status"></p>
    </header>
    <main id="contenuto"></main>
    <button class="fab" id="fab-anomalia" title="Segnala anomalia">!</button>
    <nav class="tabbar">
      ${TAB_PRINCIPALI.map(([id, label, ic]) => `
        <button data-tab="${id}" class="${statoApp.tab === id ? 'active' : ''}">
          ${icona(ic)}<span>${label}</span>
        </button>
      `).join('')}
    </nav>
  `;

  const indietroBtn = root.querySelector('#indietro-btn');
  if (indietroBtn) indietroBtn.addEventListener('click', () => vaiA('altro'));

  root.querySelectorAll('[data-tab]').forEach((btn) => {
    btn.addEventListener('click', () => vaiA(btn.dataset.tab));
  });

  root.querySelector('#fab-anomalia').addEventListener('click', () => {
    apriModaleAnomalia(statoApp.profilo, () => {
      if (statoApp.tab === 'anomalie') renderSchermata();
    });
  });

  onSyncStatusChange((stato) => {
    const el = root.querySelector('#sync-status');
    if (!el) return;
    const testi = {
      sincronizzato: '🟢 Sincronizzato',
      in_sospeso: '🟠 Non sincronizzato — verrà inviato appena c\u2019è rete',
      in_corso: 'Sincronizzazione…',
    };
    el.textContent = testi[stato] || '';
  });
}

async function renderSchermata() {
  const contenuto = root.querySelector('#contenuto');
  contenuto.innerHTML = `<div class="empty">Caricamento…</div>`;
  const p = statoApp.profilo;
  if (statoApp.tab === 'oggi') return renderOggi(contenuto, p, vaiA);
  if (statoApp.tab === 'controlli') return renderControlli(contenuto, p);
  if (statoApp.tab === 'pulizie') return renderPulizie(contenuto, p);
  if (statoApp.tab === 'anomalie') return renderAnomalie(contenuto, p);
  if (statoApp.tab === 'altro') return renderAltro(contenuto, vaiA, async () => { await signOut(); location.reload(); });
  if (statoApp.tab === 'prodotti') return renderProdotti(contenuto);
  if (statoApp.tab === 'ricevimento') return renderRicevimento(contenuto, p);
  if (statoApp.tab === 'schede-haccp') return renderSchedeHaccp(contenuto, p);
  if (statoApp.tab === 'storico') return renderStorico(contenuto);
}

function vaiA(tab) {
  statoApp.tab = tab;
  costruisciShell();
  renderSchermata();
}

async function avviaApp(session) {
  let profilo;
  try {
    profilo = await getProfilo(session.user.id);
  } catch (e) {
    root.innerHTML = `<div class="empty">
      Accesso riuscito, ma non esiste ancora un profilo collegato a questo utente
      nella tabella "profili". Vedi il README per crearlo.
      <br><br>
      <button class="btn btn-ghost" id="logout-btn">Esci</button>
    </div>`;
    root.querySelector('#logout-btn').addEventListener('click', async () => {
      await signOut();
      location.reload();
    });
    return;
  }
  statoApp.profilo = profilo;
  statoApp.tab = 'oggi';
  costruisciShell();
  renderSchermata();
}

async function avvia() {
  const session = await getSession();
  if (session) {
    await avviaApp(session);
  } else {
    renderLogin(root, async () => {
      const nuovaSessione = await getSession();
      await avviaApp(nuovaSessione);
    });
  }
}

onAuthStateChange((session) => {
  if (!session) {
    renderLogin(root, avvia);
  }
});

avvia();
